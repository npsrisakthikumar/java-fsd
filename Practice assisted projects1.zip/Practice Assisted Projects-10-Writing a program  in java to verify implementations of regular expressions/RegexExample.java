import java.util.regex.*;  
public class RegexExample{  
public static void main(String args[]){  
Pattern p = Pattern.compile(".s");//. represents single character  
Matcher m = p.matcher("as");  
boolean b = m.matches();        
System.out.println(b);  
}
}  