//using protected access specifiers
package pack1;

public class Proaccessspecifiers {

	protected void display() 
    { 
        System.out.println("This is protected access specifier"); 
    } 
}

//create another package
package pack2;

import pack1.*;

public class Accessspecifer3 extends Proaccessspecifier {

	public static void main(String[] args) {
		Accessspecifer3 obj = new Accessspecifer3 ();   
	       obj.display();  
	}

}