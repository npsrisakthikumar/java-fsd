//using public access specifiers
package pack1;

public class PubaccessSpecifier {

	public void display() 
    { 
        System.out.println("This is Public Access Specifiers"); 
    } 
}

//create another package
package pack2;
import pack1.*;

public class AccessSpecifier4 {

	public static void main(String[] args) {
		
		PubaccessSpecifier obj = new PubaccessSpecifier(); 
        obj.display();  
		
	}
}