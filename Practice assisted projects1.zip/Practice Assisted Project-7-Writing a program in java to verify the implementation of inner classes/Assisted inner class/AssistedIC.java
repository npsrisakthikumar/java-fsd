public class AssistedIC{
	 private String msg="Welcome";  
class Inner{  
	  void hello(){
                       System.out.println(msg+", Let us start learning");
              }  
}  
public static void main(String[] args) {
		AssistedIC obj=new AssistedIC();
		AssistedIC.Inner in=obj.new Inner();  
		in.hello();  
	}
}
