public class TypeCasting {

	public static void main(String[] args) {
		
	 //implicit
     int x=4;
     long y=x;
     float z=y;
     System.out.println("Before casting,int value:"+x);
     System.out.println("After casting,long value:"+y);
     System.out.println("After casting,float value:"+z);
     
     //explicit
     double a=67.33;
     int b=(int)a;
     System.out.println("Before casting,double value:"+a);
     System.out.println("After casting,int value:"+b);
     
     
		
		
	}
}