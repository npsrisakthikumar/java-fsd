import java.util.*
public class Cbyvalue {
	int a=100;
	int operation(int a) {
		a=a*100;
		return a;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Cbyvalue obj=new Cbyvalue();
		System.out.println("Value before operation "+obj.a);
		obj.operation(100);
		System.out.println("Value after operation "+obj.a);

	}

}
