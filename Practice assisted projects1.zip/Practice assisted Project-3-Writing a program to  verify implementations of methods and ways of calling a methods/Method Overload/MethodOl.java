import java.util.*
public class MethodOl {
	public void area(int b,int h) {
		System.out.println("Area of triangle:"+(0.5*b*h));
	}
	public void area(int r) {
		System.out.println("Area of circle:"+(3.14*r*r));
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MethodOl o=new MethodOl();
		o.area(8,5);
		o.area(10);

	}

}
