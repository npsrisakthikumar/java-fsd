import java.util.*
public class ExampleMethod {
      public int multi(int a,int b) {
    	  int z=a*b;
    	  return z;
      }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
         ExampleMethod c=new ExampleMethod();
         int res=c.multi(3,4);
         System.out.println("The result is "+res);
	}

}
