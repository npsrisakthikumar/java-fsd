import java.util.*;
public class DefConstrctr {
	int id;
	String name;
	void display() {
			System.out.println(id+" "+name);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DefConstrctr o=new DefConstrctr();
		DefConstrctr o1=new DefConstrctr();
		o.display();
		o1.display();

	}

}
