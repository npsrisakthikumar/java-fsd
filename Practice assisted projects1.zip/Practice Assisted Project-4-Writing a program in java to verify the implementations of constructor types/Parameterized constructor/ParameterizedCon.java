import java.util.*;
public class ParameterizedCon {
	int id;
	String name;
	int age;
	public ParameterizedCon(int i,String n,int a) {
		id=i;
		name=n;
		age=a;				
	}
	void display() {
		System.out.println(id+" "+name+" "+age);
	}
	public static void main(String[] args) {
		ParameterizedCon obj=new ParameterizedCon(111,"janu",20);
		ParameterizedCon obj1=new ParameterizedCon(222,"Krishna",23);
		obj.display();
		obj1.display();

	}

}
