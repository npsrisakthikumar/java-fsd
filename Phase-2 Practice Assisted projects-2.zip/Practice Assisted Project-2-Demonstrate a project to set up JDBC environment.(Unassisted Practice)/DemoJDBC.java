import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DemoJDBC extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Initialize JDBC and perform database operations
        // ...

        PrintWriter out = response.getWriter();
        out.println("JDBC initialized and database operations performed.");

        // Close JDBC connections and resources
        // ...
    }
}
