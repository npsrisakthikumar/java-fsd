class RunnableIf implements Runnable{  
public void run(){  
System.out.println("thread is running");  
}  
  
public static void main(String args[]){  
RunnableIf m1=new RunnableIf();  
Thread t1 =new Thread(m1);  
t1.start();  
 }  
}