class Tclass extends Thread{  
public void run(){  
System.out.println("thread is running");  
}  
public static void main(String args[]){  
Tclass t1=new Tclass();  
t1.start();  
 }  
} 